jQuery(document).ready(function($) {
    console.log('SEO Enhancer: JS Loaded');
    var $loading = $('#seo-loading');
    $loading.css('visibility', 'hidden');

    $('head').append('<style>' +
        '#seo-enhancer-container { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif; font-size: 13px; line-height: 1.4em; } ' +
        '.seo-score-wrap { margin-bottom: 15px; } ' +
        '.seo-score-wrap p { margin: 0 0 10px; font-weight: 600; } ' +
        '.seo-score-value { font-weight: bold; padding: 2px 6px; border-radius: 3px; } ' +
        '.seo-score-low { background: #ffe6e6; color: #dc3232; } ' +
        '.seo-score-medium { background: #fff4e5; color: #f56e28; } ' +
        '.seo-score-high { background: #e6f4ea; color: #46b450; } ' +
        '.seo-check-group { margin-bottom: 10px; border: 1px solid #e5e5e5; border-radius: 3px; background: #fff; box-shadow: 0 1px 1px rgba(0,0,0,0.04); } ' +
        '.seo-group-toggle { margin: 0; padding: 10px; cursor: pointer; font-size: 14px; font-weight: 600; background: #f6f7f7; border-bottom: 1px solid #e5e5e5; display: flex; align-items: center; } ' +
        '.seo-error-count { background: #dc3232; color: #fff; border-radius: 10px; padding: 2px 6px; font-size: 12px; margin-left: 5px; } ' +
        '.seo-toggle-icon { margin-left: auto; font-size: 16px; color: #666; } ' +
        '.seo-group-content { padding: 10px; list-style: none; margin: 0; display: none; } ' +
        '.seo-check-item { margin: 5px 0; display: flex; align-items: center; font-size: 13px; line-height: 1.5; } ' +
        '.seo-passed { color: #46b450; } ' +
        '.seo-failed { color: #dc3232; } ' +
        '.seo-check-status { margin-right: 5px; font-size: 16px; line-height: 1; } ' +
        '.seo-check-label { flex: 1; } ' +
        '.seo-tooltip-icon { margin-left: 5px; color: #666; cursor: help; font-size: 14px; line-height: 1; } ' +
        '.seo-tooltip-icon:hover:after { content: attr(data-tooltip); position: absolute; background: #333; color: #fff; padding: 5px 10px; border-radius: 3px; top: -30px; left: 0; white-space: normal; width: 200px; z-index: 9999; font-size: 12px; box-shadow: 0 2px 4px rgba(0,0,0,0.2); } ' +
        '.seo-inputs-wrap { margin-top: 15px; } ' +
        '.seo-inputs-wrap label { display: block; margin: 5px 0; font-weight: 600; } ' +
        '.seo-input { width: 100%; padding: 6px 8px; margin-bottom: 10px; border: 1px solid #ddd; border-radius: 3px; font-size: 13px; box-sizing: border-box; } ' +
        '.seo-actions-wrap { margin-top: 15px; } ' +
        '.seo-premium-note { margin: 5px 0 0; color: #666; font-size: 12px; font-style: italic; } ' +
        '.seo-results-wrap { margin-top: 10px; font-size: 12px; } ' +
        '</style>');

    function updateScoreDisplay(score, checkGroups) {
        console.log('SEO Enhancer: Updating score display with score:', score, 'checkGroups:', checkGroups);
        $('#seo-score-value').text(score).removeClass('seo-score-low seo-score-medium seo-score-high')
            .addClass(score < 40 ? 'seo-score-low' : (score < 80 ? 'seo-score-medium' : 'seo-score-high'));
        var html = '';
        Object.keys(checkGroups).forEach(function(group) {
            var checks = checkGroups[group];
            var errorCount = Object.values(checks).filter(check => !check.passed).length;
            html += '<div class="seo-check-group">' +
                    '<h4 class="seo-group-toggle">' +
                    group +
                    (errorCount > 0 ? ' <span class="seo-error-count">' + errorCount + ' Errors</span>' : '') +
                    '<span class="seo-toggle-icon dashicons dashicons-arrow-down-alt2"></span></h4>' +
                    '<ul class="seo-group-content">';
            Object.keys(checks).forEach(function(key) {
                html += '<li class="seo-check-item ' + (checks[key].passed ? 'seo-passed' : 'seo-failed') + '">' +
                        '<span class="seo-check-status dashicons ' + (checks[key].passed ? 'dashicons-yes' : 'dashicons-no') + '"></span>' +
                        '<span class="seo-check-label">' + checks[key].label + '</span>' +
                        '<span class="seo-tooltip-icon dashicons dashicons-info" data-tooltip="' + (checks[key].description || 'No description available') + '"></span>' +
                        '</li>';
            });
            html += '</ul></div>';
        });
        $('#seo-checks').html(html);
    }

    $(document).on('click', '.seo-group-toggle', function() {
        console.log('SEO Enhancer: Group toggle clicked:', $(this).text());
        var $toggle = $(this).find('.seo-toggle-icon');
        var $content = $(this).next('.seo-group-content');
        if ($content.is(':visible')) {
            $content.slideUp(200);
            $toggle.removeClass('dashicons-arrow-up-alt2').addClass('dashicons-arrow-down-alt2');
        } else {
            $content.slideDown(200);
            $toggle.removeClass('dashicons-arrow-down-alt2').addClass('dashicons-arrow-up-alt2');
        }
    });

    $('#seo-save-btn').on('click', function(e) {
        e.preventDefault();
        console.log('SEO Enhancer: Save Changes clicked');
        var changes = [
            { type: 'focus_keywords', value: $('#seo-focus-keywords').val() },
            { type: 'seo_title', value: $('#seo-title').val() },
            { type: 'meta_description', value: $('#seo-meta-desc').val() }
        ];
        console.log('SEO Enhancer: Committing changes:', changes);
        
        $loading.css('visibility', 'visible').addClass('is-active');
        $.ajax({
            url: seoEnhancer.ajax_url,
            type: 'POST',
            data: {
                action: 'seo_enhancer_commit_changes',
                nonce: seoEnhancer.nonce,
                post_id: seoEnhancer.post_id,
                changes: JSON.stringify(changes)
            },
            success: function(resp) {
                console.log('SEO Enhancer: Commit response:', resp);
                if (resp.success) {
                    if (typeof wp !== 'undefined' && wp.data && wp.data.dispatch) {
                        wp.data.dispatch('core/editor').editPost({ title: resp.data.updated_title });
                        console.log('SEO Enhancer: Updated Gutenberg title:', resp.data.updated_title);
                        if (seoEnhancer.seo_plugin === 'rankmath') {
                            wp.data.dispatch('rank-math').updateMeta({ description: $('#seo-meta-desc').val() });
                            console.log('SEO Enhancer: Updated Rank Math meta description:', $('#seo-meta-desc').val());
                        }
                    }
                    updateScoreDisplay(resp.data.new_score, resp.data.checks);
                    $('#seo-results').html('<p style="color: #46b450;">Changes saved successfully!</p>');
                } else {
                    console.error('SEO Enhancer: Commit failed:', resp.data);
                    $('#seo-results').html('<p style="color: #dc3232;">Error: ' + resp.data + '</p>');
                }
            },
            error: function(xhr, status, error) {
                console.error('SEO Enhancer: Commit AJAX error:', xhr.responseText);
                $('#seo-results').html('<p style="color: #dc3232;">AJAX Error: ' + error + ' - ' + xhr.responseText + '</p>');
            },
            complete: function() {
                $loading.css('visibility', 'hidden').removeClass('is-active');
            }
        });
    });
});