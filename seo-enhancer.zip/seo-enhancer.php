<?php
/*
Plugin Name: SEO Enhancer
Description: Optimizes WordPress posts and pages for better SEO scores, compatible with Rank Math, Yoast, or standalone
Version: 1.1
Author: Rick Hayes
License: GPL-2.0
*/

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class SEO_Enhancer {
    private $seo_plugin = 'none';

    public function __construct() {
        if (defined('RANK_MATH_VERSION')) {
            $this->seo_plugin = 'rankmath';
        } elseif (defined('WPSEO_VERSION')) {
            $this->seo_plugin = 'yoast';
        }
        error_log('SEO Enhancer: Detected SEO plugin: ' . $this->seo_plugin);
        
        add_action('admin_menu', [$this, 'add_admin_menu']);
        add_action('add_meta_boxes', [$this, 'add_meta_box']);
        add_action('wp_ajax_seo_enhancer_commit_changes', [$this, 'ajax_commit_changes']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_scripts']);
    }

    public function add_admin_menu() {
        add_menu_page(
            'SEO Enhancer',
            'SEO Enhancer',
            'manage_options',
            'seo-enhancer',
            [$this, 'settings_page_callback'],
            'dashicons-chart-line',
            6
        );
    }

    public function settings_page_callback() {
        ?>
        <div class="wrap">
            <h1>SEO Enhancer</h1>
            <p>Enhance your WordPress SEO with manual optimization tools. Upgrade to premium for advanced features.</p>
        </div>
        <?php
    }

    public function add_meta_box() {
        add_meta_box(
            'seo_enhancer_box',
            'SEO Enhancer',
            [$this, 'render_meta_box'],
            ['post', 'page'],
            'side',
            'high'
        );
        error_log('SEO Enhancer: Meta box added');
    }

    public function render_meta_box($post) {
        wp_nonce_field('seo_enhancer_nonce', 'seo_enhancer_nonce');
        error_log('SEO Enhancer: Rendering meta box for post ' . $post->ID);
        $current_keywords = $this->seo_plugin === 'rankmath' ? get_post_meta($post->ID, '_rank_math_focus_keyword', true) : ($this->seo_plugin === 'yoast' ? get_post_meta($post->ID, '_yoast_wpseo_focuskw', true) : get_post_meta($post->ID, 'seo_enhancer_focus_keywords', true));
        $current_keywords = is_array($current_keywords) ? $current_keywords : ($current_keywords ? explode(',', $current_keywords) : []);
        $current_title = $this->seo_plugin === 'rankmath' ? get_post_meta($post->ID, '_rank_math_title', true) : ($this->seo_plugin === 'yoast' ? get_post_meta($post->ID, '_yoast_wpseo_title', true) : get_post_meta($post->ID, 'seo_enhancer_seo_title', true));
        $current_title = $current_title ?: $post->post_title;
        $current_desc = $this->seo_plugin === 'rankmath' ? get_post_meta($post->ID, '_rank_math_description', true) : ($this->seo_plugin === 'yoast' ? get_post_meta($post->ID, '_yoast_wpseo_metadesc', true) : get_post_meta($post->ID, 'seo_enhancer_meta_description', true));
        $check_groups = [];
        $initial_score = $this->calculate_seo_score($post->post_content, $current_keywords, $current_title, $current_desc, $check_groups);
        ?>
        <div id="seo-enhancer-container">
            <div id="seo-score" class="seo-score-wrap">
                <p><strong>SEO Score:</strong> <span id="seo-score-value" class="<?php echo $initial_score < 40 ? 'seo-score-low' : ($initial_score < 80 ? 'seo-score-medium' : 'seo-score-high'); ?>"><?php echo esc_html($initial_score); ?></span>/100</p>
                <div id="seo-checks">
                    <?php
                    foreach ($check_groups as $group => $checks) {
                        $error_count = count(array_filter($checks, function($check) { return !$check['passed']; }));
                        ?>
                        <div class="seo-check-group">
                            <h4 class="seo-group-toggle">
                                <?php echo esc_html($group); ?>
                                <?php if ($error_count > 0): ?>
                                    <span class="seo-error-count"><?php echo $error_count; ?> Errors</span>
                                <?php endif; ?>
                                <span class="seo-toggle-icon dashicons dashicons-arrow-down-alt2"></span>
                            </h4>
                            <ul class="seo-group-content">
                                <?php foreach ($checks as $key => $check): ?>
                                    <li class="seo-check-item <?php echo $check['passed'] ? 'seo-passed' : 'seo-failed'; ?>">
                                        <span class="seo-check-status dashicons <?php echo $check['passed'] ? 'dashicons-yes' : 'dashicons-no'; ?>"></span>
                                        <span class="seo-check-label"><?php echo esc_html($check['label']); ?></span>
                                        <span class="seo-tooltip-icon dashicons dashicons-info" data-tooltip="<?php echo esc_attr($check['description']); ?>"></span>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                        <?php
                    }
                    ?>
                </div>
            </div>
            <div id="seo-inputs" class="seo-inputs-wrap">
                <label><strong>Focus Keywords</strong> (comma-separated):</label>
                <textarea id="seo-focus-keywords" rows="2" class="seo-input"><?php echo esc_html(implode(',', $current_keywords)); ?></textarea>
                <label><strong>SEO Title</strong> (60-70 chars):</label>
                <input type="text" id="seo-title" value="<?php echo esc_attr($current_title); ?>" class="seo-input" maxlength="70">
                <label><strong>Meta Description</strong> (120-160 chars):</label>
                <textarea id="seo-meta-desc" rows="3" class="seo-input" maxlength="160"><?php echo esc_html($current_desc); ?></textarea>
            </div>
            <div id="seo-actions" class="seo-actions-wrap">
                <button id="seo-save-btn" class="button button-primary">Save Changes</button>
                <p class="seo-premium-note">Automatic optimization available in Premium.</p>
            </div>
            <div id="seo-loading" class="spinner" style="margin-top: 10px; visibility: hidden;"></div>
            <div id="seo-results" class="seo-results-wrap"></div>
        </div>
        <?php
    }

    public function enqueue_scripts($hook) {
        if (!in_array($hook, ['post.php', 'post-new.php', 'toplevel_page_seo-enhancer'])) {
            return;
        }
        
        wp_enqueue_style('dashicons');
        $js_path = plugin_dir_path(__FILE__) . 'seo-enhancer.js';
        $js_url = plugin_dir_url(__FILE__) . 'seo-enhancer.js';
        if (!file_exists($js_path)) {
            error_log('SEO Enhancer: JS file not found at: ' . $js_path);
        }
        wp_enqueue_script(
            'seo-enhancer-script',
            $js_url,
            ['jquery'],
            '1.1.' . (file_exists($js_path) ? filemtime($js_path) : time()),
            true
        );
        
        wp_localize_script('seo-enhancer-script', 'seoEnhancer', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('seo_enhancer_ajax'),
            'post_id' => get_the_ID(),
            'seo_plugin' => $this->seo_plugin
        ]);
        error_log('SEO Enhancer: Scripts enqueued for hook: ' . $hook . ', JS URL: ' . $js_url);
    }

    private function calculate_seo_score($content, $focus_keywords, $title, $description, &$check_groups = null) {
        $score = 0;
        $focus_keywords = is_array($focus_keywords) ? $focus_keywords : ($focus_keywords ? explode(',', $focus_keywords) : []);
        $focus_keywords = array_map('trim', array_filter($focus_keywords));
        error_log('SEO Enhancer: Calculating SEO score with title: ' . $title . ', keywords: ' . implode(',', $focus_keywords));
        
        $content_words = str_word_count(strip_tags($content));
        $keyword_count = array_sum(array_map(function($kw) use ($content) { return substr_count(strtolower($content), strtolower($kw)); }, $focus_keywords));
        $density = $content_words > 0 ? ($keyword_count / $content_words) * 100 : 0;
        $slug = basename(get_permalink());

        $basic_seo_checks = [
            'title_keyword' => ['label' => 'Add Focus Keyword to the SEO title', 'passed' => count(array_filter($focus_keywords, function($kw) use ($title) { return stripos($title, $kw) === 0; })) > 0, 'description' => 'Primary keyword should be at the start of the title to improve relevance and visibility in search results.'],
            'desc_keyword' => ['label' => 'Add Focus Keyword to the SEO Meta Description', 'passed' => count(array_filter($focus_keywords, function($kw) use ($description) { return stripos($description, $kw) !== false; })) > 0, 'description' => 'Include keywords in meta description to improve click-through rates and relevance.'],
            'url_keyword' => ['label' => 'Use Focus Keyword in the URL', 'passed' => count(array_filter($focus_keywords, function($kw) use ($slug) { return stripos($slug, $kw) !== false; })) > 0, 'description' => 'Keywords in slug improve relevance and make the URL more user-friendly.'],
            'intro_keyword' => ['label' => 'Use Focus Keyword at the beginning of your content', 'passed' => count(array_filter($focus_keywords, function($kw) use ($content, $content_words) { return stripos(substr($content, 0, $content_words * 0.1), $kw) !== false; })) > 0, 'description' => 'Keywords in first 10% of content to establish relevance early on.'],
            'density' => ['label' => 'Use Focus Keyword in the content', 'passed' => $density >= 0.8 && $density <= 2.5, 'description' => 'Balanced keyword usage (0.8-2.5%) to avoid over-optimization and improve readability.'],
            'content_length' => ['label' => 'Content is ' . $content_words . ' words long. Good job!', 'passed' => $content_words >= 600, 'description' => 'Sufficient content depth (600+ words) to provide comprehensive information and improve search engine ranking.'],
        ];

        $additional_checks = [
            'subheading_keyword' => ['label' => 'Use Focus Keyword in subheading(s)', 'passed' => preg_match('/<h[2-6][^>]*>.*?(' . implode('|', array_map('preg_quote', $focus_keywords)) . ').*?<\/h[2-6]>/i', $content), 'description' => 'Keywords in H2/H3 tags to improve content structure and relevance.'],
            'internal_links' => ['label' => 'Add 1-5 internal links to your content', 'passed' => preg_match_all('/<a\s[^>]*href=["\']([^"\']*?)["\'][^>]*>/i', $content, $links) && count(array_filter($links[1], function($href) { return strpos($href, home_url()) === 0; })) >= 1 && count(array_filter($links[1], function($href) { return strpos($href, home_url()) === 0; })) <= 5, 'description' => 'Link to other pages on your site to improve navigation and distribute link equity.'],
            'external_links' => ['label' => 'Add 1-3 external links to your content', 'passed' => preg_match_all('/<a\s[^>]*href=["\']([^"\']*?)["\'][^>]*>/i', $content, $links) && count(array_filter($links[1], function($href) { return strpos($href, home_url()) !== 0; })) >= 1 && count(array_filter($links[1], function($href) { return strpos($href, home_url()) !== 0; })) <= 3, 'description' => 'Link to authoritative external sources to establish credibility and provide additional value.'],
        ];

        $sentences = preg_split('/[.!?]+/', strip_tags($content), -1, PREG_SPLIT_NO_EMPTY);
        $flesch = $this->calculate_flesch($content);
        $long_sentences = count(array_filter($sentences, function($s) { return str_word_count(trim($s)) > 20; }));
        $sentence_ratio = $sentences ? $long_sentences / count($sentences) : 0;

        $readability_checks = [
            'flesch_score' => ['label' => 'Flesch score should be 60-70', 'passed' => $flesch >= 60 && $flesch <= 70, 'description' => 'Readable for general audience to ensure content is accessible to a wider audience.'],
            'sentence_length' => ['label' => 'Less than 25% of sentences should be >20 words', 'passed' => $sentence_ratio < 0.25, 'description' => 'Keep sentences concise to improve readability and engagement.'],
        ];

        $check_groups = [
            'Basic SEO' => $basic_seo_checks,
            'Additional' => $additional_checks,
            'Readability' => $readability_checks,
        ];

        foreach ($basic_seo_checks as $check) {
            if ($check['passed']) $score += 5;
        }
        foreach ($additional_checks as $check) {
            if ($check['passed']) $score += 5;
        }
        foreach ($readability_checks as $check) {
            if ($check['passed']) $score += 5;
        }

        return min($score, 100);
    }

    private function calculate_flesch($content) {
        $text = strip_tags($content);
        $words = str_word_count($text);
        $sentences = count(preg_split('/[.!?]+/', $text, -1, PREG_SPLIT_NO_EMPTY));
        $syllables = 0;
        foreach (preg_split('/\s+/', $text) as $word) {
            $syllables += preg_match_all('/[aeiouy]+/i', $word);
        }
        return $words && $sentences ? 206.835 - 1.015 * ($words / $sentences) - 84.6 * ($syllables / $words) : 0;
    }

    public function ajax_commit_changes() {
        check_ajax_referer('seo_enhancer_ajax', 'nonce');
        error_log('SEO Enhancer: Commit AJAX called');
        
        $post_id = intval($_POST['post_id']);
        $changes = json_decode(stripslashes($_POST['changes']), true);
        
        if (!$post_id || !is_array($changes)) {
            error_log('SEO Enhancer: Invalid data - Post ID: ' . $post_id . ', Changes: ' . print_r($changes, true));
            wp_send_json_error('Invalid request data');
        }

        $post_data = ['ID' => $post_id];
        $updated = false;

        foreach ($changes as $change) {
            $type = strtolower($change['type']);
            $value = $change['value'];
            error_log('SEO Enhancer: Processing type: ' . $type . ', value: ' . (is_array($value) ? implode(',', $value) : $value));
            
            switch ($type) {
                case 'focus_keywords':
                    $key = $this->seo_plugin === 'rankmath' ? '_rank_math_focus_keyword' : ($this->seo_plugin === 'yoast' ? '_yoast_wpseo_focuskw' : 'seo_enhancer_focus_keywords');
                    $keywords = is_array($value) ? $value : explode(',', $value);
                    $keywords = array_map('trim', array_filter($keywords));
                    $result = update_post_meta($post_id, $key, implode(',', $keywords));
                    error_log('SEO Enhancer: Updated focus keywords meta (' . $key . '): ' . ($result !== false ? 'Success' : 'Failed') . ', Value: ' . implode(',', $keywords));
                    $updated = true;
                    break;
                case 'seo_title':
                    $key = $this->seo_plugin === 'rankmath' ? '_rank_math_title' : ($this->seo_plugin === 'yoast' ? '_yoast_wpseo_title' : 'seo_enhancer_seo_title');
                    $result = update_post_meta($post_id, $key, sanitize_text_field($value));
                    error_log('SEO Enhancer: Updated SEO title meta (' . $key . '): ' . ($result !== false ? 'Success' : 'Failed') . ', Value: ' . $value);
                    $post_data['post_title'] = sanitize_text_field($value);
                    $updated = true;
                    break;
                case 'meta_description':
                    $key = $this->seo_plugin === 'rankmath' ? '_rank_math_description' : ($this->seo_plugin === 'yoast' ? '_yoast_wpseo_metadesc' : 'seo_enhancer_meta_description');
                    $result = update_post_meta($post_id, $key, sanitize_text_field($value));
                    error_log('SEO Enhancer: Updated meta description meta (' . $key . '): ' . ($result !== false ? 'Success' : 'Failed') . ', Value: ' . $value);
                    $updated = true;
                    break;
            }
        }

        if (!empty($post_data['post_title'])) {
            $result = wp_update_post($post_data, true);
            if (is_wp_error($result)) {
                error_log('SEO Enhancer: Post update failed: ' . $result->get_error_message());
                wp_send_json_error('Failed to update post: ' . $result->get_error_message());
            } else {
                error_log('SEO Enhancer: Post updated successfully: ' . print_r($post_data, true));
            }
        }

        if ($updated) {
            wp_cache_flush();
            clean_post_cache($post_id);
            error_log('SEO Enhancer: Cache cleared for post ID: ' . $post_id);

            $post = get_post($post_id);
            $current_keywords = get_post_meta($post_id, $this->seo_plugin === 'rankmath' ? '_rank_math_focus_keyword' : ($this->seo_plugin === 'yoast' ? '_yoast_wpseo_focuskw' : 'seo_enhancer_focus_keywords'), true);
            $current_keywords = is_array($current_keywords) ? $current_keywords : ($current_keywords ? explode(',', $current_keywords) : []);
            $current_title = get_post_meta($post_id, $this->seo_plugin === 'rankmath' ? '_rank_math_title' : ($this->seo_plugin === 'yoast' ? '_yoast_wpseo_title' : 'seo_enhancer_seo_title'), true) ?: $post->post_title;
            $current_desc = get_post_meta($post_id, $this->seo_plugin === 'rankmath' ? '_rank_math_description' : ($this->seo_plugin === 'yoast' ? '_yoast_wpseo_metadesc' : 'seo_enhancer_meta_description'), true);
            $check_groups = [];
            $new_score = $this->calculate_seo_score($post->post_content, $current_keywords, $current_title, $current_desc, $check_groups);

            error_log('SEO Enhancer: New SEO score: ' . $new_score . ', Keywords used: ' . implode(',', $current_keywords));

            wp_send_json_success([
                'message' => 'Changes committed successfully',
                'post_id' => $post_id,
                'updated_title' => $post->post_title,
                'new_score' => $new_score,
                'checks' => $check_groups
            ]);
        } else {
            error_log('SEO Enhancer: No changes applied');
            wp_send_json_error('No changes were applied');
        }
    }
}

new SEO_Enhancer();